import React, {useState} from 'react'
import Form from './Form'
import Weather from './Weather'
import "../css/index.css"

function App() {
    const [weather, setWeather] = useState({});
    const [city, setCity] = useState('');
    
    return (
        <div className="central">
            <Form setWeather={setWeather} city={city} setCity={setCity}/>
            {Object.keys(weather).length === 0 ? "" : <Weather weather={weather}/>}
        </div>
    )
}
export default App