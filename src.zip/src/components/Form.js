import React from 'react'
import axios from 'axios'

const Form = ({setWeather, city, setCity}) => {
    const getWeather = (e) => {
        e.preventDefault();
        let API_KEY = '2c790b6acd182334dec8b2d1ebd9b35f';
        axios(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}`)
        .then(({data}) => setWeather(data))
        .catch(() => alert('Enter city/country correctly'))
    setCity('');
    };
    const inputHandler = (e) => {
        setCity(e.target.value)
    };
    return (
        <form action="" onSubmit={getWeather}>
            <input className="input" type="text" placeholder="Enter city/country" onChange={inputHandler} value={city}/>
        </form>
    )
}
export default Form