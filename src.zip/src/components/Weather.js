import React from 'react'

const Weather = ({weather, sf}) => {
    function remove() {
        document.querySelector(".container").remove()
    }
    let temp = Math.round(weather.main.temp - 273.15)
    return (
        <div className="container">
            <div className="weather-side">
            <div className="weather-gradient"></div>
            <div className="date-container">
                <h2 className="date-dayname">{weather.name}</h2>
                <span class="location">{weather.sys.country}</span>
            </div>
            <div className="weather-container">
            <img src={`http://openweathermap.org/img/wn/${weather.weather[0].icon}@4x.png`} className="weather-icon" data-feather="sun"/>
                <h1 className="weather-temp">{temp}°С</h1>
                <h3 className="weather-desc">{weather.weather[0].main}</h3>
            </div>
        </div>
        <div className="info-side">
        <div className="today-info-container">
            <div className="today-info">
                <div> <span className="title">PRECIPITATION</span><span className="value">{weather.clouds.all} %</span>
                    <div className="clear"></div>
                </div>
                <div className="humidity"> <span className="title">HUMIDITY</span><span className="value">{weather.main.humidity} %</span>
                    <div className="clear"></div>
                </div>
                <div className="wind"> <span className="title">WIND</span><span className="value">{weather.wind.speed} m/s</span>
                    <div className="clear"></div>
                </div>
                <div className="advice"> <span className="title">ADVICE:</span><span className="value">
                    {temp < 10 ? "It's very cold now, put on your jacket" : temp < 20 ? "it's cold now, dress warmly" : temp < 29 ? "Temperature is normal, dress what you want" : "Heat, drink more water"}
                </span>
                    <div className="clear"></div>
                </div>
            </div>
        </div>
        <div className="week-container">
        </div>
        <div className="location-container"><button className="location-button" onClick={remove}> <i data-feather="map-pin"></i><span>Change location</span></button></div>
        </div>
        </div>
    )
}
export default Weather